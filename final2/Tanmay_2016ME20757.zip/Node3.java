//package final2;

public class Node3 {

	public String element;
	public Node point;
	public Node3 left;
	public Node3 right;
	public Node3 parent;
}
