//package final2;

import java.util.*;

public class Node {

	public String object;
	public Node parent;
	public Vector<Node> children = new Vector<>();
	public int level;
}
