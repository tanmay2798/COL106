//package ass4;


public class Node {
	public String key = new String();
	public String value=new String();


	public Node(String key, String value) {
		this.key=key;
		this.value=value;
	}
}
